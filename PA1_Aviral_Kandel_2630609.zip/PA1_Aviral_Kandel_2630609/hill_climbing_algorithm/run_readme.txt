This code is written in python language. Submlime text was used as it's editor. 
Thus Ctrl+B is used to run this code.